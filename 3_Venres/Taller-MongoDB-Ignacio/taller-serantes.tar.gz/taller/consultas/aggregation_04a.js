db.scrobbles.aggregate([
  {$group: 
    {"_id": "$title", "count": {$sum:1}}
  },     
  {$sort: 
    {count: -1}
  },
  {$limit: 10},
  {$skip: 5}
])
