db.scrobbles.aggregate([
  {$group: 
    {"_id": "$title", "count": {$sum:1}}
  } 
])
