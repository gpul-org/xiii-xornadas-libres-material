db.scrobbles.aggregate([
  {$group: 
    {"_id": "$title", "count": {$sum:1}}
  },     
  {$sort: 
    {count: -1}
  },
  {$skip: 5},
  {$limit: 10}
])
