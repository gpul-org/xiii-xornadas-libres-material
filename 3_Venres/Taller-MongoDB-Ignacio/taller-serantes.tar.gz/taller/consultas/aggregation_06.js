db.scrobbles.aggregate([
  {$match:
    {artists: "Krystal"}
  },
  {$group:
    {"_id": {"title": "$title", "artists": "$artists"}, "count": {$sum:1}}
  },
  {$sort:
    {count: -1}
  },
  {$limit: 10},
])
