#!/usr/bin/env python2
# -*- coding: UTF-8 -*-

# Python main libraries.
import HTMLParser, json, os, re, subprocess, sys, time, xml.sax.saxutils

# MongoDB related.
import bson, bson.json_util, pymongo

# Own libraries.
import libSession

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
MAIN_TITLE = u"Taller"
MAIN_TITLE_RUBY = u"MongoDB, Python y Flask"
MAIN_SUBTITLE = u"Taller de introducción al desarrollo de aplicaciones web"
MAIN_AUTHOR = u'Ignacio Serantes'

ENCODING = sys.getfilesystemencoding()

MONGODB_HOST="localhost"

connection = pymongo.MongoClient("mongodb://" + MONGODB_HOST)
mongoDB = connection.taller
mongoDB_Scrobbles = mongoDB.scrobbles


RECORDSET_LIMIT = 20
RECORDSET_LIMIT_BIG = 128


def html_escape(text):
    #return xml.sax.saxutils.escape(text).replace('"', "%22").replace("'", "%27").replace("&", "%26").replace("?", "%3F")
    return text.replace('"', "%22").replace('#', '%23').replace("'", "%27").replace("&", "%26").replace("?", "%3F")

def html_unescape(text):
    return HTMLParser.HTMLParser().unescape(text)



#
# cServer  class.
#
class cServer:

    def __init__(self):
        pass


    def home(self):
        return render_template('home.html', page_title = MAIN_TITLE, page_title_ruby = MAIN_TITLE_RUBY, site_url = request.host)


    def login(self, username = '', password = '', referer = ''):
        credentialsAuthenticated = False
        if (username == None):
            username = ''

        if (referer == None):
            referer = ''

        if (username != ""):
            credentialsAuthenticated = credentialsAuthenticated \
                                            or ((username == u"ignacio") and (password == u""))

        if credentialsAuthenticated:
            session[username] = username

        if (referer == '') or (username == ""):
            result = render_template("login.html", \
                                page_title = MAIN_TITLE,\
                                username = username, \
                                referer = referer, \
                                authenticated = credentialsAuthenticated)
        else:
            result = redirect('/%s/%s' % (referer, username), code = 302)

        return result


    def logout(self, username = ''):
        if (username == None):
            username = ''

        if (username != ''):
            session.pop(username, None)

        return redirect('/', code = 302)


    def getUserScrobbles(self, username = "", kind = "", data = ""):
        cursor = None

        if (username == None):
            username = ""

        try:
            if (kind == ""):
                #EJERCICIO 1: Cubrir query y sort con los valores adecuados.
                query = {}
                projection = {"_id": 0, "title": 1, "artists": 1, "album": 1, "albumartists": 1, "genres": 1, "timestamp": 1}
                sort = []
                #EJERCICIO 1
                cursor = mongoDB_Scrobbles.find(query, projection).sort(sort).limit(RECORDSET_LIMIT)

            elif (kind in ("album", "albums")):
                if (data == ""):
                    #EJERCICIO 2: Álbumes más escuchados.
                    pipeline = []
                    #EJERCICIO 2

                else:
                    #EJERCICIO 3: Canciones más escuchadas por album, el título viene en la variable "data".
                    pipeline = []
                    #EJERCICIO 3


                cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"]

            elif (kind in ("artist", "artists")):
                if (data == ""):
                    #EJERCICIO 4: Artistas más escuchados.
                    pipeline = [{"$unwind": "$artists" },
                                    {"$match": {"user": username, "status": {"$exists": False}}},
                                    {"$group": {"_id": "$artists", "count": {"$sum": 1}}},
                                    {"$sort": {"count": -1}},
                                    {"$limit": RECORDSET_LIMIT}
                                ]
                    pipeline = []
                    #EJERCICIO 4

                else:
                    #EJERCICIO 5: Canciones más escuchadas por artista, el nombre viene en la variable "data".
                    pipeline = []
                    #EJERCICIO 5

                cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"]

            elif (kind in ("genre", "genres")):
                if (data == ""):
                    #EJERCICIO 6: Géneros más escuchados.
                    pipeline = [{"$unwind": "$genres" },
                                    {"$match": {"user": username, "status": {"$exists": False}}},
                                    {"$group": {"_id": "$genres", "count": {"$sum": 1}}},
                                    {"$sort": {"count": -1}},
                                    {"$limit": RECORDSET_LIMIT}
                                ]
                    pipeline = []
                    #EJERCICIO 6

                else:
                    #EJERCICIO 7: Canciones más escuchadas por género, el género viene en la variable "data".
                    pipeline = []
                    #EJERCICIO 7

                cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"]

            elif (kind in ("title", "titles")):
                if (data == ""):
                    #EJERCICIO 8: Títulos más escuchados.
                    pipeline = []
                    #EJERCICIO 8

                else:
                    #EJERCICIO 9: Número de veces que se escuchó una canción, el título vien en la variable "data".
                    pipeline = []
                    #EJERCICIO 9

                cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"]

            elif (kind == ("count_albums")):
                if (data == ""):
                    #EJERCICIO 10: Contar el número de álbumes diferentes.
                    pipeline = []
                    #EJERCICIO 10

                else:
                    #EJERCICIO 11: Contar el número de canciones de un álbum, el título viene en la variable "data".
                    pipeline = []
                    #EJERCICIO 11

                try:
                    cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"][0]["count"]

                except:
                    cursor = 0


            elif (kind == ("count_artists")):
                if (data == ""):
                    #EJERCICIO 12: Contar el número de artistas distintos.
                    pipeline = []
                    #EJERCICIO 12

                else:
                    #EJERCICIO 13: Contar el número de canciones de un artista, el nombre viene en la variable "data".
                    pipeline = []
                    #EJERCICIO 13

                try:
                    cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"][0]["count"]

                except:
                    cursor = 0


            elif (kind == ("count_genres")):
                if (data == ""):
                    #EJERCICIO 14: Contar el número de géneros.
                    pipeline = []
                    #EJERCICIO 14

                else:
                    #EJERCICIO 15: Contar el número de canciones por género, el género viene en la variable "data".
                    pipeline = [{"$unwind": "$genres" },
                                    {"$match": {"user": username, "status": {"$exists": False}, "genres": data}},
                                    {"$group": {"_id": {"title": "$title"}}},
                                    {"$group": {"_id": 0, "count": {"$sum": 1}}}
                                ]
                    pipeline = []
                    #EJERCICIO 15

                try:
                    cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"][0]["count"]

                except:
                    cursor = 0

            elif (kind == ("count_scrobbles")):
                pipeline = [{"$match": {"user": username, "status": {"$exists": False}}},
                                {"$group": {"_id": 0, "count": {"$sum": 1}}}
                            ]
                pipeline = []

                try:
                    cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"][0]["count"]

                except:
                    cursor = 0

            elif (kind == ("count_songs")):
                pipeline = [{"$match": {"user": username, "status": {"$exists": False}}},
                                {"$group": {"_id": 0, "count": {"$sum": 1}}}
                            ]
                pipeline = []

                try:
                    cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"][0]["count"]

                except:
                    cursor = 0

            elif (kind == ("count_titles")):
                if (data == ""):
                    pipeline = [{"$match": {"user": username, "status": {"$exists": False}}},
                                    {"$group": {"_id": {"title": "$title", "artists": "$artists"}}},
                                    {"$group": {"_id": 0, "count": {"$sum": 1}}}
                                ]
                    pipeline = []

                else:
                    pipeline = [{"$match": {"user": username, "status": {"$exists": False}, "title": data}},
                                    {"$group": {"_id": 0, "count": {"$sum": 1}}}
                                ]
                    pipeline = []

                try:
                    cursor = mongoDB.command("aggregate", "scrobbles", pipeline = pipeline)["result"][0]["count"]

                except:
                    cursor = 0

        except:
            print("Unexpected error:", sys.exc_info()[0])

        return cursor


    def cleanUrlPaths(self, path = ""):
        if (path == None):
            path = ''

        if (os.path.basename(path) == ""):
            path = os.path.dirname(path)

        return path

#
# Aquí empieza el código de flask.
#
from flask import Flask, redirect, render_template, request, Response, send_file, session
from jinja2 import Environment

app = Flask(__name__)

server = cServer()

@app.route("/")
@app.route("/home")
def home():
    """
        Building a home page for the server.
    """
    return server.home()

@app.route("/login", methods=['GET','POST'])
def login():
    """
        Login.
    """
    result = None
    username = password = referer = ""
    try:
        username = request.form['username']

    except:
        pass

    try:
        password = request.form['password']

    except:
        pass

    try:
        referer = request.args.get('referer')

    except:
        pass

    if ((referer == "") or (referer == None)):
        try:
            referer = request.form['referer']

        except:
            pass

    if (username == None):
        username = ""

    if (password == None):
        password = ""

    if (referer == None):
        referer = ""

    return server.login(username, password, referer)


@app.route("/logout")
@app.route("/logout/<path:username>")
def logout(username = ''):
    """
        Logout.
    """
    return server.logout(username)


@app.route("/scrobbles/")
@app.route("/scrobbles/<path:username>")
@app.route("/scrobbles/<path:username>/<path:kind>")
@app.route("/scrobbles/<path:username>/<path:kind>/<path:data>")
def scrobbles(username = "", kind = "", data = ""):
    """
        Display user scrobbles.
    """
    if not (username in session):
        return redirect('/login?referer=scrobbles', code = 302)

    if (username != ""):
        cursor = server.getUserScrobbles(username, kind, data)
        songTitle = ''
        songArtist = ''
        if (kind == ""):
            songs_count = server.getUserScrobbles(username, 'count_songs', data)
            template = "scrobbles.html"
            song_title = song_artists = ''
            if (cursor.count() > 0):
                #cursorClone = cursor.clone()
                if ("title" in cursor[0].keys()):
                    song_title = cursor[0]["title"]
                    try:
                        song_artists = ", ".join(cursor[0]["artists"])

                    except:
                        song_artists = ""

            page_subtitle = "<p><H3><em>%s's</em> last %s played songs out of %s</h3></p>" \
                                % (username, RECORDSET_LIMIT, songs_count)

            return render_template(template, \
                        page_title = MAIN_TITLE, \
                        page_subtitle = page_subtitle, \
                        site_url = request.host, \
                        username = username, \
                        song_title = html_escape(song_title), \
                        song_artist = html_escape(song_artists), \
                        scrobbles = cursor, \
                        songs_count = songs_count
                    )

        elif (kind in ("album", "albums")):
            albums_count = server.getUserScrobbles(username, 'count_albums', data)
            if (data == ""):
                template = "scrobbles_albums.html"
                page_subtitle = "<p><H3><em>%s's</em> top %s played albums out of %s</h3></p>" \
                                    % (username, RECORDSET_LIMIT, albums_count)

            else:
                template = "scrobbles_titles.html"
                page_subtitle = "<p><H3></em>%s's</em> top %s played titles on album \"%s\" out of %s</h3></p>" \
                                    % (username, RECORDSET_LIMIT, data, albums_count)

            return render_template(template, \
                        page_title = MAIN_TITLE, \
                        page_subtitle = page_subtitle, \
                        site_url = request.host, \
                        username = username, \
                        scrobbles = cursor, \
                        albums_count = albums_count
                    )

        elif (kind in ("artist", "artists")):
            artists_count = server.getUserScrobbles(username, 'count_artists', data)
            if (data == ""):
                template = "scrobbles_artists.html"
                page_subtitle = "<p><H3><em>%s's</em> top %s played artists out of %s</h3></p>" \
                                    % (username, RECORDSET_LIMIT, artists_count)

            else:
                template = "scrobbles_titles.html"
                page_subtitle = "<p><H3><em>%s's</em> top %s played titles by artist \"%s\" out of %s</h3></p>" \
                                    % (username, RECORDSET_LIMIT, data, artists_count)

            return render_template(template, \
                        page_title = MAIN_TITLE, \
                        page_subtitle = page_subtitle, \
                        site_url = request.host, \
                        username = username, \
                        scrobbles = cursor, \
                        artists_count = artists_count
                    )

        elif (kind in ("genre", "genres")):
            genres_count = server.getUserScrobbles(username, 'count_genres', data)
            if (data == ""):
                template = "scrobbles_genres.html"
                page_subtitle = "<p><H3><em>%s's</em> top %s played genres out of %s</h3></p>" \
                                    % (username, RECORDSET_LIMIT, genres_count)


            else:
                template = "scrobbles_titles.html"
                page_subtitle = "<p><H3><em>%s's</em> \"%s\" top %s played titles out of %s</h3></p>" \
                                    % (username, data, RECORDSET_LIMIT, genres_count)

            return render_template(template, \
                        page_title = MAIN_TITLE, \
                        page_subtitle = page_subtitle, \
                        site_url = request.host, \
                        username = username, \
                        scrobbles = cursor, \
                        genres_count = genres_count
                    )

        elif (kind in ("title", "titles")):
            titles_count = server.getUserScrobbles(username, 'count_titles', data)
            template = "scrobbles_titles.html"
            if (data == ""):
                page_subtitle = "<p><H3><em>%s's</em> top %s titles out of %s</h3></p>" \
                                    % (username, RECORDSET_LIMIT, titles_count)

            else:
                page_subtitle = "<p><H3><em>%s</em> played \"%s\" %s times</h3></p>" \
                                    % (username, data, titles_count)

            return render_template(template, \
                        page_title = MAIN_TITLE, \
                        page_subtitle = page_subtitle, \
                        site_url = request.host, \
                        username = username, \
                        scrobbles = cursor, \
                        titles_count = titles_count
                    )

    return render_template('404.html', \
                                page_title = MAIN_TITLE), 404


@app.route("/songs_count/<path:username>")
def songs_count(username = ''):
    result = 0

    if (username != ''):
        try:
            result = server.getUserScrobbles(username, 'songs_count')

        except:
            pass

    return Response("%s" % (result), mimetype = "text/plain")


@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html', \
                            page_title = MAIN_TITLE), 404


@app.errorhandler(500)
def page_not_found(error):
    return render_template('500.html', \
                            page_title = MAIN_TITLE),

if (__name__ == "__main__"):
    # set the secret key.  keep this really secret:
    app.secret_key = '9824rsdfaAAAAÑÑÑ.-089odfsfsfi'
    app.session_interface = libSession.MongoSessionInterface(db = 'music', user = 'mpd', password = 'mpd', collection = 'sessions', host = 'miryo.aynoa.net')
    app.run(host = '0.0.0.0', port = 5000, debug = True)
